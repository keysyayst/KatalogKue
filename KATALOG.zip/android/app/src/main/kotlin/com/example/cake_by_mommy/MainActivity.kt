package com.example.cake_by_mommy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
